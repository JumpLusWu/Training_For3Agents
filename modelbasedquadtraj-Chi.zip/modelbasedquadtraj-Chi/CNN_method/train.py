import numpy as np
import tensorflow as tf 
import pickle
import pdb


file = open("capt-xdata.pickle",'rb')
x_data = pickle.load(file)
file.close()



file = open("capt-ydata.pickle",'rb')
y_data = pickle.load(file)
file.close()


pdb.set_trace()