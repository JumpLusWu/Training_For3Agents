# modelbasedquadtraj
In the main.py, I implemented 'verifyData' and 'generateDate' functions. The former would test the distance constraints 
and the latter would save vaild locations and its corresponding assignment into files.

In order to load data from files, I implemented the 'loadTrainingData.py', which would load training data from given files,
(default is 'distanceMatrices.csv' and 'assignmentMatrices.csv'). And the function would also transform assignment matrices
into required form so that it could be used to train sub-models.

I have generated 100,000 data points, serving as the toy data set to verify the paper's idea. The number of robots equals 
to the number of goals, which are both 4. The number is in line with the configuration in the paper. Feel free to divide 
the training dataset into training, validation and testing sets. 
