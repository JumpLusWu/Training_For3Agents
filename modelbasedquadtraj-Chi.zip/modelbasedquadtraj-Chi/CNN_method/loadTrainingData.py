import numpy as np
from keras.utils import to_categorical

"""
Read training data including locations and assignments from given files.
Transform the data into required shape.
"""
def loadTrainingData(X_file='distanceMatrices.csv', Y_file='assignmentMatrics.csv'):
    """
    (INPUT) x_file: the directory of the file that stores robots and goals location;
    (INPUT) y_file: the directory of the file that stores cost matrices
    (OUTPUT) distanceMatrices: NX(M*M) matrix, where N is the number of data, 
                M is the number of robots/goals
    (OUTPUT) assignment_onehot: MxNxM, the first M is the number of sub-models;
                                 N is the number of data;
                                 the second M is the number of assignments/robots/goals.
    """

    # distanceMatrices = np.loadtxt('distanceMatrices.csv',dtype=float)
    # assignment = np.loadtxt('assignmentMatrices.csv',dtype=int)
    distanceMatrices = np.loadtxt(X_file,dtype=float)
    assignmentMatrices = np.loadtxt(Y_file,dtype=int)

    N,M = assignmentMatrices.shape

    # Create a MxNxM matrices,within which matrices[i,:,:] is the ground truth for model i
    assignment_onehot = np.zeros((M, N, M))
    for i in range(M):
        assignment_onehot[i,:,:] = to_categorical(assignmentMatrices[:,i],num_classes=M)
        print(assignment_onehot[i,:,:])
    
    distanceMatrices = distanceMatrices.reshape((N,4,4,1))

    return [distanceMatrices, assignment_onehot]